# Deepslate Dungeon Datapack Change log
- ### by Dohst
- ### last review 06/10/2023

## Version 1.0
- Unknown

## Version 2.0 (??/09/2023 - 06/10/2023) (minecraft 1.19)
- added info file with general datapack information 
- changed pack image
- added advancements (find_deepslate_dungeon, root)
- added a lot more structures for more random generation (instead of previously only one structure)
- added more processors for more variety 
- more biome structure generators
- changed structure generation settings
- changed spacing and separation 
- changed template_pool files to handle new structures 

### Version 2.1 (22/02/2024 - 22/02/2024) (minecraft 1.20.4)
- updated from 1.20.4
- made it more balanced
- removed the ore room
- removed diamond / netherite generation
- changed some of the generation chances
- removed some of the spawners
